
describe('edocs-av', function(){
    it('should force file to be evaluated', (done) => {
        done();
    });
});