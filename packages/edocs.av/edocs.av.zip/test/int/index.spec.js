const should = require('should');

describe('edocs-av', function(){
    // placeholder
    it('should force file to be evaluated', (done) => {
        done();
    });
});
